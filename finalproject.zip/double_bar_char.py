import sqlite3
import os
import time
import requests
import json
import random
import sys
import csv
from bs4 import BeautifulSoup
import matplotlib
import matplotlib.pyplot as plt

path = os.path.dirname(os.path.abspath(__file__))
conn = sqlite3.connect(path+'/'+"finalproject.db")
cur = conn.cursor()
# extracting info from database
y = cur.execute("SELECT Billboard.song_title, Billboard.song_artist, iTunesExplicitness.explicitness, iTunesGenre.genre FROM Billboard JOIN iTunesExplicitness JOIN iTunesGenre ON iTunesExplicitness.song_name = Billboard.song_title AND iTunesGenre.song_name = Billboard.song_title")
y = cur.fetchall()

# makes a new list without repeats
lst = []
for x in y:
    if x not in lst:
        lst.append(x)

# sorts the number of genres into explicit and not explict dictionaries
dic = {}
explicit_dic = {}
not_explicit_dic = {}

for x in lst:
    if x[2] == 'explicit':
        if x[3] not in explicit_dic.keys():
            explicit_dic[x[3]] = 1
        else:
            explicit_dic[x[3]] += 1
    if x[2] == 'notExplicit' or x[2] == 'cleaned':
        if x[3] not in not_explicit_dic.keys():
            not_explicit_dic[x[3]] = 1
        else:
            not_explicit_dic[x[3]] += 1

# print(explicit_dic)
# print(not_explicit_dic)

# counting total number of songs in list
total = 0
for x in explicit_dic:
    total += explicit_dic[x]
for x in not_explicit_dic:
    total += not_explicit_dic[x]
# print(total)

# preparing lists for each axis
explicit_x_axis = []
explicit_y_axis = []
not_explicit_x_axis = []
not_explicit_y_axis = []

for x in explicit_dic.keys():
    explicit_x_axis.append(x)
    explicit_y_axis.append(explicit_dic[x])
for x in not_explicit_dic.keys():
    not_explicit_x_axis.append(x)
    not_explicit_y_axis.append(not_explicit_dic[x])

# print(explicit_x_axis)
# print(explicit_y_axis)
# print(not_explicit_x_axis)
# print(not_explicit_y_axis)

lst2 = []
for x in lst:
    if x[3] not in lst2 and x[3] != '':
        lst2.append(x[3])

# first graph
width = 0.4
fig, ax = plt.subplots()
p1 = ax.bar(explicit_x_axis, explicit_y_axis, width, color='blue')
# p2 = ax.bar(not_explicit_x_axis, not_explicit_y_axis, width, color='red')

ax.set_xlabel("Genres")
ax.set_ylabel("Number of Explicit Songs")
ax.set_xticks(explicit_x_axis)
ax.set_title("Number of Explicit Songs VS. Genres")
ax.grid()
ax.autoscale_view()

fig.savefig("Number of Explicit songs VS. Genres.png")

plt.show()

# second graph
width = 0.4
fig, ax = plt.subplots()
p2 = ax.bar(not_explicit_x_axis, not_explicit_y_axis, width, color='red')

ax.set_xlabel("Genres")
ax.set_ylabel("Number of Non-Explicit Songs")
ax.set_xticks(not_explicit_x_axis)
ax.set_title("Number of Non-Explicit Songs VS. Genres")
ax.grid()
ax.autoscale_view()

fig.savefig("Number of Non-Explicit songs VS. Genres.png")

plt.show()
