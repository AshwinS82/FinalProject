import sqlite3
import os
import time
import requests
import json
import random
import sys
from bs4 import BeautifulSoup
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

# Set up database
path = os.path.dirname(os.path.abspath(__file__))
conn = sqlite3.connect(path+'/'+"finalproject.db")
cur = conn.cursor()

# Get necessary data
y = cur.execute("SELECT iTunesGenre.genre FROM iTunesGenre")
y = cur.fetchall()

# Input data into dictionary
d = {}
for i in y:
    d[i[0]] = d.get(i[0], 0) + 1
# Create 'Other' and expand 'Latin' Categories
d['Latin'] = d['Latin'] + d['Urbano latino'] + d['Pop Latino'] + d['Rock y Alternativo']
d['Other'] = d['K-Pop'] + d['Classical Crossover'] + d['Dance']
if 'Urbano latino' in d:
    d.pop('Urbano latino')
if 'Pop Latino' in d:
    d.pop('Pop Latino')
if 'Rock y Alternativo' in d:
    d.pop('Rock y Alternativo')
if 'K-Pop' in d:
    d.pop('K-Pop')
if '' in d:
    d.pop('')
if 'Classical Crossover' in d:
    d.pop('Classical Crossover')
if 'Dance' in d:
    d.pop('Dance')

#Create inputs for graph
label = d.keys()
values = d.values()
color = ['lightcoral', 'darkorange', 'lime', 'skyblue', 'khaki', 'cyan', 'violet', 'deeppink']
explodes = (0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1)

#Create and save graph
plt.pie(values, explode=explodes, labels=label, colors=color, autopct='%1.1f%%', shadow=False, startangle=190)
plt.title("Percent of Billboard Hot 100 by Genre")
plt.axis('equal')
'''
first_patch = mpatches.Patch(color='lightcoral', label='Hip-Hop/Rap')
second_patch = mpatches.Patch(color='darkorange', label='Holiday')
third_patch = mpatches.Patch(color='lime', label='Pop')
fourth_patch = mpatches.Patch(color='skyblue', label='Latin')
fifth_patch = mpatches.Patch(color='khaki', label='Country')
sixth_patch = mpatches.Patch(color='cyan', label='R&B/Soul')
seventh_patch = mpatches.Patch(color='violet', label='Alternative')
eighth_patch = mpatches.Patch(color='deeppink', label='Other')
plt.legend(handles=[first_patch, second_patch, third_patch, fourth_patch, fifth_patch, sixth_patch, seventh_patch, eighth_patch])
'''
plt.savefig("genrepie.png")


plt.show()

