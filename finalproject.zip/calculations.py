import sqlite3
import os
import time
import requests
import json
import random
import sys
import csv
from bs4 import BeautifulSoup

path = os.path.dirname(os.path.abspath(__file__))
conn = sqlite3.connect(path+'/'+"finalproject.db")
cur = conn.cursor()


y = cur.execute("SELECT Billboard.song_title, Billboard.song_artist, iTunesExplicitness.explicitness, iTunesGenre.genre, imdb.movie_title FROM Billboard JOIN iTunesExplicitness JOIN iTunesGenre JOIN imdb ON iTunesExplicitness.song_name = Billboard.song_title AND iTunesGenre.song_name = Billboard.song_title AND imdb.artist_name = Billboard.song_artist")
y = cur.fetchall()

x = cur.execute("SELECT Billboard.song_title, Billboard.song_artist, iTunesExplicitness.explicitness, iTunesGenre.genre, imdb.movie_title FROM Billboard JOIN iTunesExplicitness JOIN iTunesGenre JOIN imdb ON iTunesExplicitness.song_name = Billboard.song_title AND iTunesGenre.song_name = Billboard.song_title AND imdb.artist_name = Billboard.song_artist WHERE iTunesExplicitness.explicitness = 'explicit' AND iTunesGenre.genre = 'Hip-Hop/Rap' AND imdb.movie_title != 0")
x = cur.fetchall()

lst = []
for song in y:
    if song not in lst:
        lst.append(song)

lst2 = []
for item in lst:
    if item[4] != '0' and item[3] == 'Hip-Hop/Rap':
        lst2.append(item)


percent_explicit_hiphop_movie = str((len(lst2) / len(lst)) * 100) + "%"
print("The percent of explicit songs in the hip/hop genre that have a movie is " + percent_explicit_hiphop_movie)

path = os.path.dirname(__file__)
rel_path = "test.csv"
filename = os.path.join(path, rel_path)
fieldnames = ["song_title","song_artist", "explicitness", "genre", "movie_title","match"]
with open(filename, 'w', newline = '') as csv_file:
    write = csv.writer(csv_file, delimiter = ',', quotechar = '"')
    write.writerow(fieldnames)
    for i in lst:
        b = False
        for song_title in lst2:
            if i[4] == song_title[4]:
                b = True
        match = "Yes"
        if b == False:
            match = "No"
        write.writerow([i[0],i[1],i[2],i[3],i[4],match])




    
    
