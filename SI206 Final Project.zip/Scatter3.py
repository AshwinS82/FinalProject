import sqlite3
import os
import time
import requests
import json
import random
import sys
from bs4 import BeautifulSoup
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

# Set up database
path = os.path.dirname(os.path.abspath(__file__))
conn = sqlite3.connect(path+'/'+"finalproject.db")
cur = conn.cursor()

y = cur.execute("SELECT Billboard.weeksOnChart FROM Billboard")
y = cur.fetchall()
z = []
for i in y:
    z.append(i[0])


x = cur.execute("SELECT Billboard.peak FROM Billboard")
x = cur.fetchall()
w = []
for i in x:
    w.append(i[0])

plt.scatter(z, w, color = 'gold')
plt.xlabel('Weeks on Chart')
plt.ylabel('Peak Ranking')
plt.title("Weeks on Billboard 500 vs. Peak Ranking")

plt.show()