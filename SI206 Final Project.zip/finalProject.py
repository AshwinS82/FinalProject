import sqlite3
import os
import time
import requests
import json
import random
import sys
from bs4 import BeautifulSoup

# Returns list of information about each song
def iTunes_API(song, artist):
    new_artist = artist
    new_song = song
    if " " in artist:
        new_artist = artist.replace(" ", "+")
    if " " in song:
        new_song = song.replace(" ", "+")
    base_url = "https://itunes.apple.com/search?"
    term = new_artist + "+" + new_song
    url = base_url + "term=" + term + "&" + "entity=musicTrack" + "&" + "limit=25"
    #print(url)
# interacting with api
    try:
        data1 = requests.get(url).json()

        dic = data1["results"][0]
# extracting info out of python object
        artist_name = artist
        song_name = song
        genre = dic["primaryGenreName"]
    #album_name = dic["collectionName"]
        explicitness = dic["trackExplicitness"]
        lst = [song_name, artist_name, genre, explicitness]
    except:
        song_name = song
        artist_name = artist
        genre = ""
        explicitness = ""
        lst = [song_name, artist_name, genre, explicitness]
    #print(lst)
    return lst


def imdbapi(artistname):
    artist_name = artistname
    if " " in artistname:
        artist_name = artistname.replace(" ","+")
    baseurl = "http://www.omdbapi.com/?t=" + artist_name + "&apikey=87541ab8"
    response = requests.get(baseurl)
    res = response.json()
    try:
        if res["Error"] == 'Movie not found!':
            movie_title = 0
            year_released = 0
            Genre = 0
    except:
        movie_title = res["Title"]
        year_released = res["Year"]
        Genre = res["Genre"]
    lst = [movie_title, year_released, Genre]
    return lst


path = os.path.dirname(os.path.abspath(__file__))
conn = sqlite3.connect(path+'/'+"finalproject.db")
cur = conn.cursor()
cur.execute("CREATE TABLE IF NOT EXISTS Billboard (rank INTEGER UNIQUE, song_title TEXT, song_artist TEXT, peak INTEGER, weeksOnChart INTEGER)")


url = "https://www.billboard.com/charts/hot-100"
page = requests.get(url)
soup = BeautifulSoup(page.text, 'html.parser')
songs = soup.find_all(class_ = "chart-list__element display--flex")
count = 0  
lastIndex = 1
song_lst = []
for song in songs:
    if (count < 25):
        rankCode = song.find(class_ = "chart-element__rank__number")
        rank = int(rankCode.contents[0])
                        
        titleCode = song.find(class_ = "chart-element__information__song text--truncate color--primary")
        title = titleCode.contents[0]
                        
        artistCode = song.find(class_ ="chart-element__information__artist text--truncate color--secondary")
        artist = artistCode.contents[0]

        
        if "Featuring" in artist:
            a = artist.split("Featuring")
            artist = a[0]
        if "&" in artist:
            a = artist.split("&")
            artist = a[0]
        if "x" in artist:
            a = artist.split("x")
            artist = a[0]
        if "With" in artist:
            a = artist.split("With")
            artist = a[0]
        if "+" in artist:
            a = artist.split("+")
            artist = a[0]
        if "And " in artist:
            a = artist.split("And")
            artist = a[0]
       
                        
        peakCode = song.find(class_ = "chart-element__meta text--center color--secondary text--peak")
        peak = int(peakCode.contents[0])
                        
        weeksCode = song.find(class_ = "chart-element__meta text--center color--secondary text--week")
        weeks = int(weeksCode.contents[0])

        try:
            if(rank == lastIndex):
                cur.execute("INSERT INTO Billboard (rank,song_title,song_artist,peak,weeksOnChart) VALUES (?,?,?,?,?)",(rank, title, artist, peak, weeks))
                conn.commit()
                lastIndex = lastIndex + 1
                #print((rank, title, artist, peak, weeks))
                song_lst.append([title, artist])
                count = count + 1
        
        except:
            lastIndex = lastIndex + 1    


# iTunes API and to Database
cur.execute("CREATE TABLE IF NOT EXISTS iTunesGenre (song_name TEXT, artist_name TEXT, genre TEXT)")
cur.execute("CREATE TABLE IF NOT EXISTS iTunesExplicitness (song_name TEXT, artist_name TEXT, explicitness TEXT)")
cur.execute("CREATE TABLE IF NOT EXISTS imdb (artist_name TEXT, movie_title TEXT, year_released INTEGER, Genre TEXT)")
for song in song_lst:
    lst3 = iTunes_API(song[0],song[1])
    lst4 = imdbapi(song[1])
    cur.execute("INSERT INTO iTunesGenre (song_name, artist_name, genre) VALUES (?,?,?)",(lst3[0],lst3[1],lst3[2]))
    cur.execute("INSERT INTO iTunesExplicitness (song_name, artist_name, explicitness) VALUES (?,?,?)",(lst3[0],lst3[1],lst3[3]))
    cur.execute("INSERT INTO imdb (artist_name, movie_title, year_released, Genre) VALUES (?,?,?,?)", (lst3[1],lst4[0],lst4[1],lst4[2]))
conn.commit()


