import matplotlib
import matplotlib.pyplot as plt
import sqlite3
import os
import time
import requests
import json
import random
import sys
import csv
from bs4 import BeautifulSoup

path = os.path.dirname(os.path.abspath(__file__))
conn = sqlite3.connect(path+'/'+"finalproject.db")
cur = conn.cursor()

s = cur.execute("SELECT imdb.year_released FROM imdb")
# Data for plotting
s = cur.fetchall()

    
dic = {}
for x in s:
    if x not in dic.keys():
        dic[x] = 1
    else:
        dic[x] += 1
z = dic.keys()
l = []
m = []
for a in z:
    l.append(a[0])
for w in l:
    if type(w) == int:
        m.append(w)
    else:
        w = w.replace("–", "")
        w = w[0:4]
        w = int(w)
        m.append(w)
dic1 = {}
for q in m:
    if q not in dic1.keys():
        dic1[q] = 1
    else:
        dic1[q] += 1


print(dic1)
dic1.pop(0)
lst1 = dic1.values()
lst2 = dic1.keys()

print(lst1)
print(lst2)

# Create horizontal bar graph
width = .9
fig, ax = plt.subplots()
p1 = ax.bar(lst2, lst1, width, color = "green")

ax.set_xlabel("Year Released")
ax.set_ylabel("Count of year released")
ax.set_title("Number of movies released by artists per year")
ax.grid()


fig.savefig("IMDBGRAPH")

plt.show()




